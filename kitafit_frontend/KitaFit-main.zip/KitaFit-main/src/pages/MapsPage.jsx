export default function MapsPage() {
  return <div className='p-6 text-center text-xl'>MapsPage (Halaman)</div>;
}