export default function ChatbotPage() {
  return <div className='p-6 text-center text-xl'>ChatbotPage (Halaman)</div>;
}