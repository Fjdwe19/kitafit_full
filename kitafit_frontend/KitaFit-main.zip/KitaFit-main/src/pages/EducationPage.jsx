export default function EducationPage() {
  return <div className='p-6 text-center text-xl'>EducationPage (Halaman)</div>;
}