export default function ResultPage() {
  return <div className='p-6 text-center text-xl'>ResultPage (Halaman)</div>;
}